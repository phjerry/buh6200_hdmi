<html>
<head>
<title>Hotspot 2.0 subscription remediation</title>
</head>
<body>

<?php

echo "SessionID: " . $_GET["session_id"] . "<br>\n";

echo "<a href=\"redirect.php?id=" . $_GET["session_id"] . "\">Complete user subscription remediation</a><br>\n";

?>

This will provide a new machine-generated password.

</body>
</html>
